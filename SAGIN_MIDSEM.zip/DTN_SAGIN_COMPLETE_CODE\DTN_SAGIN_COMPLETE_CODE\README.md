# DTN-SAGIN Complete Source Code

This folder contains the final source code for the DTN-SAGIN digital-twin task-offloading study. It includes the proposed `P_DTN-HQ` method, baseline variants, environment and twin models, classical QUBO/BQM optimization, simulation runner, metric calculation, automated tests, and the final plotting program.

## Contents

- `env/`: SAGIN configuration, topology generation, channel model, feasibility checks, baseline decision rules, and physical metric evaluation.
- `twin/`: Digital-twin state, AoI, uncertainty, mismatch, fidelity, synchronization, and coordination logic.
- `opt/`: Local QUBO construction, classical QUBO solver, BQM assignment solver, and hierarchical optimization helpers.
- `control/`: Regional projection and inter-node coordination control.
- `sim/`: End-to-end simulation runner and command-line entry point.
- `results/`: Result metrics and CSV/JSON output utilities.
- `generate_measured_baseline_plots.py`: Final experiment and PNG figure-generation script.
- `test_*.py`: Unit and model-validation tests.

## Baselines Included

The simulation and figure script evaluate the proposed `P_DTN-HQ` and the required baseline variants, including greedy link-quality, channel-oriented, digital-twin-free, AoI-unaware, trust-unaware, always-on, uncertainty-unaware triggering, local/centralized QUBO, local search, and static-risk variants as applicable per experiment.

## Dependencies

Install the dependencies with:

```powershell
python -m pip install -r requirements.txt
```

## Run Tests

From this folder:

```powershell
python -m unittest discover -v
```

## Run the Simulator

```powershell
python -m sim.main
```

## Generate Figures

```powershell
python generate_measured_baseline_plots.py
```

The QUBO/BQM experiments use local classical solvers; no quantum-hardware or cloud API claim is made by this code package.
