from __future__ import annotations

from collections import defaultdict

from env.config import SimulationConfig
from env.evaluator import PhysicalEvaluator
from env.feasibility import FeasibilityManager, ResourceUsage
from env.models import APNode, CandidateScore, FinalAssignment, LocalSummary, Task


class RegionalController:
    """Hierarchical one-hot projection under the shared physical constraints."""

    def __init__(
        self,
        strategy: str = "hierarchical",
        config: SimulationConfig | None = None,
    ):
        self.strategy = strategy
        self.config = config or SimulationConfig()
        self.evaluator = PhysicalEvaluator(self.config)
        self.feasibility = FeasibilityManager(self.config)

    def project(
        self,
        local_summaries: list[LocalSummary],
        ap_lookup: dict[str, APNode],
        tasks: list[Task],
    ) -> list[FinalAssignment]:
        scores_by_task: dict[str, list[CandidateScore]] = defaultdict(list)
        for summary in local_summaries:
            for score in summary.candidate_scores:
                scores_by_task[score.task_id].append(score)

        sync_ap_ids = {
            summary.ap_id for summary in local_summaries if summary.sync_triggered
        }
        coord_ap_ids = {
            summary.ap_id
            for summary in local_summaries
            if summary.coordination_triggered
        }
        usage: dict[str, ResourceUsage] = defaultdict(ResourceUsage)
        selected: dict[str, str] = {}

        remaining = {task.task_id: task for task in tasks}
        while remaining:
            choices: list[tuple[int, float, str, CandidateScore]] = []
            for task_id, task in remaining.items():
                feasible = [
                    score
                    for score in self._rank_scores(
                        scores_by_task.get(task_id, []),
                        task,
                        ap_lookup,
                    )
                    if self.feasibility.can_add(
                        task,
                        ap_lookup[score.destination_id],
                        usage[score.destination_id],
                    )
                ]
                if feasible:
                    choices.append(
                        (
                            len(feasible),
                            self._ranking_cost(feasible[0], task, ap_lookup),
                            task_id,
                            feasible[0],
                        )
                    )

            if not choices:
                break

            if self.strategy == "greedy":
                _, _, task_id, winner = min(choices, key=lambda item: item[1:])
            else:
                _, _, task_id, winner = min(choices)
            task = remaining.pop(task_id)
            selected[task_id] = winner.destination_id
            usage[winner.destination_id] = self.feasibility.add(
                task,
                usage[winner.destination_id],
            )

        for task_id in remaining:
            selected[task_id] = "LOCAL"

        return self.materialize_mapping(
            selected,
            tasks,
            ap_lookup,
            sync_ap_ids,
            coord_ap_ids,
        )

    def materialize_mapping(
        self,
        mapping: dict[str, str],
        tasks: list[Task],
        ap_lookup: dict[str, APNode],
        sync_ap_ids: set[str] | None = None,
        coord_ap_ids: set[str] | None = None,
    ) -> list[FinalAssignment]:
        """Evaluate every algorithm's mapping under one full outcome model."""
        sync_ap_ids = sync_ap_ids or set()
        coord_ap_ids = coord_ap_ids or set()
        task_map = {task.task_id: task for task in tasks}
        assigned_per_ap: dict[str, int] = defaultdict(int)
        for task in tasks:
            destination = mapping.get(task.task_id, "LOCAL")
            if destination in ap_lookup:
                assigned_per_ap[destination] += 1

        assignments: list[FinalAssignment] = []
        for task in tasks:
            destination = mapping.get(task.task_id, "LOCAL")
            if destination not in ap_lookup:
                assignments.append(self._local_execution_assignment(task))
                continue

            ap = ap_lookup[destination]
            metrics = self.evaluator.evaluate_remote(
                task,
                ap,
                assigned_per_ap[destination],
                sync_active=destination in sync_ap_ids,
                coord_active=destination in coord_ap_ids,
            )
            assignments.append(
                FinalAssignment(
                    task_id=task.task_id,
                    owner_ap_id=task.owner_ap_id,
                    destination_id=destination,
                    local_cost=self.evaluator.proposed_cost(metrics),
                    delay_cost=metrics.total_delay_s,
                    energy_cost=metrics.total_energy_j,
                    mission_cost=metrics.freshness_risk,
                    fidelity_cost=metrics.fidelity_penalty,
                )
            )

        assert len(assignments) == len(task_map)
        return assignments

    def _local_execution_assignment(self, task: Task) -> FinalAssignment:
        metrics = self.evaluator.evaluate_local(task)
        return FinalAssignment(
            task_id=task.task_id,
            owner_ap_id=task.owner_ap_id,
            destination_id="LOCAL",
            local_cost=self.evaluator.proposed_cost(metrics),
            delay_cost=metrics.total_delay_s,
            energy_cost=metrics.total_energy_j,
            mission_cost=metrics.freshness_risk,
            fidelity_cost=metrics.fidelity_penalty,
        )

    def _rank_scores(
        self,
        scores: list[CandidateScore],
        task: Task,
        ap_lookup: dict[str, APNode],
    ) -> list[CandidateScore]:
        return sorted(
            scores,
            key=lambda score: self._ranking_cost(score, task, ap_lookup),
        )

    def _ranking_cost(
        self,
        score: CandidateScore,
        task: Task,
        ap_lookup: dict[str, APNode],
    ) -> float:
        fidelity_violation = (
            ap_lookup[score.destination_id].twin_state.fidelity < task.F_u_min
        )
        return float(
            score.local_cost
            + score.coupling_penalty
            + (
                self.config.fidelity_violation_penalty
                if fidelity_violation
                else 0.0
            )
        )
