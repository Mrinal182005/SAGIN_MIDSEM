"""Run real SAGIN-DTN baseline experiments and plot measured results.

This script executes the proposed method and all eleven baselines specified in
Prompt_strings_11Baselines.pdf. Every plotted value is aggregated from simulator
run outputs; no y-value profiles are embedded in this file.

Usage:
    python generate_measured_baseline_plots.py
    python generate_measured_baseline_plots.py --slots 50 --seeds 7,13,21
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from statistics import mean, pstdev

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse

from env.config import SimulationConfig
from opt.solver import ClassicalQuboSolver
from sim.runner import SimulationRunner


METHODS = {
    "proposed": {
        "symbol": r"$\mathcal{P}_{\mathrm{DTN-HQ}}$",
        "description": "Proposed closed-loop DTN + Local Classical QUBO guidance",
        "color": "#0072B2",
        "marker": "o",
        "linestyle": "-",
        "algorithm": "proposed",
        "decision_profile": "full",
        "projection": "hierarchical",
        "solver_backend": "classical",
        "use_solver_guidance": True,
        "sync_policy": "event",
        "coord_policy": "event",
    },
    "greedy": {
        "symbol": r"$\mathcal{B}_{\mathrm{GLQ}}$",
        "description": "Greedy Link-Quality",
        "color": "#D55E00",
        "marker": "s",
        "linestyle": "--",
        "algorithm": "greedy",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "centralized_qubo": {
        "symbol": r"$\mathcal{B}_{\mathrm{CQ}}$",
        "description": "Centralized QUBO",
        "color": "#009E73",
        "marker": "^",
        "linestyle": "-.",
        "algorithm": "centralized_qubo",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "channel_only": {
        "symbol": r"$\mathcal{B}_{\mathrm{CH}}$",
        "description": "Channel-Only Predictive",
        "color": "#E69F00",
        "marker": "v",
        "linestyle": "-.",
        "algorithm": "channel_only",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "dt_free": {
        "symbol": r"$\mathcal{B}_{\mathrm{DTF}}$",
        "description": "DT-Free Distributed",
        "color": "#CC79A7",
        "marker": "D",
        "linestyle": ":",
        "algorithm": "dt_free",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "static_risk": {
        "symbol": r"$\mathcal{B}_{\mathrm{SR}}$",
        "description": "Static-Risk Distributed",
        "color": "#56B4E9",
        "marker": "P",
        "linestyle": (0, (4, 1)),
        "algorithm": "static_risk",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "aoi_unaware": {
        "symbol": r"$\mathcal{B}_{A^-}$",
        "description": "AoI-Unaware Distributed",
        "color": "#009E73",
        "marker": "^",
        "linestyle": (0, (5, 2)),
        "algorithm": "aoi_unaware",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "event",
        "coord_policy": "never",
    },
    "trust_unaware": {
        "symbol": r"$\mathcal{B}_{\tau^-}$",
        "description": "Trust-Unaware Distributed",
        "color": "#9467BD",
        "marker": "<",
        "linestyle": (0, (3, 1, 1, 1)),
        "algorithm": "trust_unaware",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "always_on": {
        "symbol": r"$\mathcal{B}_{\mathrm{AO}}$",
        "description": "Always-On Sync/Coordination",
        "color": "#000000",
        "marker": "*",
        "linestyle": "-",
        "algorithm": "always_on",
        "decision_profile": "full",
        "projection": "hierarchical",
        "solver_backend": "classical",
        "use_solver_guidance": True,
        "sync_policy": "always",
        "coord_policy": "always",
    },
    "local_qubo": {
        "symbol": r"$\mathcal{B}_{\mathrm{LQ}}$",
        "description": "Classical Same-Objective Local QUBO/BQM",
        "color": "#9467BD",
        "marker": "<",
        "linestyle": (0, (3, 1, 1, 1)),
        "algorithm": "local_qubo",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "local_search": {
        "symbol": r"$\mathcal{B}_{\mathrm{LS}}$",
        "description": "Classical Same-Objective Local Search",
        "color": "#7F7F7F",
        "marker": ">",
        "linestyle": "--",
        "algorithm": "local_search",
        "decision_profile": "full",
        "projection": "baseline",
        "solver_backend": "none",
        "use_solver_guidance": False,
        "sync_policy": "never",
        "coord_policy": "never",
    },
    "uncertainty_unaware": {
        "symbol": r"$\mathcal{B}_{\mathrm{UUT}}$",
        "description": "Uncertainty-Unaware Periodic Trigger",
        "color": "#17BECF",
        "marker": "d",
        "linestyle": (0, (5, 1)),
        "algorithm": "uncertainty_unaware",
        "decision_profile": "full",
        "projection": "hierarchical",
        "solver_backend": "classical",
        "use_solver_guidance": True,
        "sync_policy": "periodic",
        "coord_policy": "periodic",
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--slots", type=int, default=30)
    parser.add_argument("--seeds", default="7,13,21,31,43")
    parser.add_argument("--anneal-reads", type=int, default=2)
    parser.add_argument("--anneal-sweeps", type=int, default=5)
    parser.add_argument("--tasks", default="20,40,60,80,100")
    parser.add_argument("--aoi-values", default="1,3,5,7,9,11")
    parser.add_argument("--speeds", default="5,10,15,20,25,30")
    parser.add_argument("--sync-thresholds", default="1,2,3,4,5,6")
    parser.add_argument("--tradeoff-thresholds", default="1,2,3,4,5,6,7,8")
    parser.add_argument("--coord-thresholds", default="0.05,0.10,0.15,0.20,0.25")
    parser.add_argument("--output-dir", default="measured_baseline_results")
    parser.add_argument(
        "--replot-from",
        default="",
        help="Existing measured results directory containing *_raw.csv files; replots figures without rerunning simulations.",
    )
    parser.add_argument("--dpi", type=int, default=350)
    return parser.parse_args()


def parse_ints(raw: str) -> list[int]:
    return [int(part.strip()) for part in raw.split(",") if part.strip()]


def parse_floats(raw: str) -> list[float]:
    return [float(part.strip()) for part in raw.split(",") if part.strip()]


def configure_plots(dpi: int) -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 10,
            "axes.labelsize": 11,
            "legend.fontsize": 8.5,
            "figure.dpi": 150,
            "savefig.dpi": dpi,
            "savefig.bbox": "tight",
            "axes.grid": True,
            "grid.alpha": 0.24,
            "grid.linestyle": ":",
            "mathtext.fontset": "stix",
        }
    )


def method_config(base: SimulationConfig, method_key: str, run_dir: Path) -> SimulationConfig:
    meta = METHODS[method_key]
    return replace(
        base,
        output_dir=str(run_dir),
        algorithm=meta["algorithm"],
        decision_profile=meta["decision_profile"],
        local_solver_backend=meta["solver_backend"],
        use_solver_guidance=bool(meta["use_solver_guidance"]),
        sync_trigger_policy=meta["sync_policy"],
        coord_trigger_policy=meta["coord_policy"],
    )


def run_method(method_key: str, config: SimulationConfig) -> dict[str, float]:
    runner = SimulationRunner(config)
    if METHODS[method_key]["projection"] != "baseline":
        runner.regional_controller.strategy = METHODS[method_key]["projection"]
    if config.local_solver_backend.lower() == "none":
        runner.local_solver = None
    elif config.local_solver_backend.lower() == "annealing":
        runner.local_solver = ClassicalQuboSolver(config, backend="annealing")

    slots, summary, output_path = runner.run()
    warmup = min(config.warmup_slots, max(len(slots) - 1, 0))
    measured_slots = slots[warmup:] or slots
    assigned_counts = np.array([max(len(slot.assignments), 1) for slot in measured_slots], dtype=float)
    total_cost = np.array([sum(item.local_cost for item in slot.assignments) for slot in measured_slots], dtype=float)
    total_delay = np.array([slot.total_delay for slot in measured_slots], dtype=float)
    total_energy = np.array([slot.total_energy for slot in measured_slots], dtype=float)
    mission_cost = np.array([slot.mission_cost for slot in measured_slots], dtype=float)
    fidelity = np.array(
        [np.mean([summary_item.fidelity for summary_item in slot.local_summaries]) for slot in measured_slots],
        dtype=float,
    )
    sync = np.array([slot.sync_trigger_count for slot in measured_slots], dtype=float)
    coord = np.array([slot.coordination_trigger_count for slot in measured_slots], dtype=float)
    solver_time = np.array(
        [sum(summary_item.solver_time for summary_item in slot.local_summaries) for slot in measured_slots],
        dtype=float,
    )
    decision_time = np.array(
        [slot.decision_runtime_seconds for slot in measured_slots],
        dtype=float,
    )
    return {
        "avg_delay": float(np.mean(total_delay / assigned_counts)),
        "avg_energy": float(np.mean(total_energy / assigned_counts)),
        "avg_total_energy": float(np.mean(total_energy)),
        "avg_total_cost": float(np.mean(total_cost)),
        "avg_mission_cost": float(np.mean(mission_cost / assigned_counts)),
        "avg_fidelity": float(np.mean(fidelity)),
        "avg_sync": float(np.mean(sync)),
        "avg_coord": float(np.mean(coord)),
        "avg_solver_runtime_ms": float(np.mean(solver_time) * 1000.0),
        "avg_runtime_ms": float(np.mean(decision_time) * 1000.0),
        "total_runtime_ms": float(np.sum(decision_time) * 1000.0),
        "output_path": output_path,
        "sync_triggers": float(summary["sync_triggers"]),
        "coord_triggers": float(summary["coord_triggers"]),
    }


def aggregate(rows: list[dict[str, object]], metric: str) -> list[dict[str, object]]:
    grouped: dict[tuple[str, float], list[float]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["method"]), float(row["x"]))].append(float(row[metric]))
    out = []
    for (method, x_value), values in sorted(grouped.items(), key=lambda item: (item[0][0], item[0][1])):
        out.append(
            {
                "method": method,
                "x": x_value,
                "mean": mean(values),
                "std": pstdev(values) if len(values) > 1 else 0.0,
                "n": len(values),
            }
        )
    return out


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def read_rows(path: Path) -> list[dict[str, object]]:
    # Replot mode reads already measured CSV files. This avoids rerunning the
    # simulator when only figure styling, labels, or zoom placement changes.
    with path.open(newline="", encoding="utf-8") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def measured_x_values(rows: list[dict[str, object]]) -> list[float]:
    # The x-axis values must come from the actual experiment sweep, not from a
    # manually chosen plotting range. This keeps the figure tied to measured data.
    return sorted({float(row["x"]) for row in rows})


def apply_measured_xlim(ax, x_values: list[float]) -> None:
    # Start and stop each x-axis exactly at the measured sweep endpoints. This
    # avoids misleading blank space before/after the real experiment range.
    values = sorted(float(value) for value in x_values)
    if not values:
        return
    if len(values) == 1:
        pad = max(abs(values[0]) * 0.05, 0.5)
        ax.set_xlim(values[0], values[0] + pad)
        return
    ax.set_xlim(values[0], values[-1])


def add_zoom_inset(
    ax,
    agg: list[dict[str, object]],
    methods: list[str],
    *,
    x_window: tuple[float, float] | None = None,
    loc: str = "center",
    zoom_methods: list[str] | None = None,
) -> None:
    # A zoom inset is a visual aid only. It redraws the same aggregated values
    # in a smaller axis; it does not modify the measured data or smooth curves.
    all_x = measured_x_values(agg)
    if len(all_x) < 3:
        return

    if x_window is None:
        # Default zoom window focuses on the middle of the sweep, where multiple
        # baselines often overlap and trends are hardest to read.
        start = all_x[max(1, len(all_x) // 3)]
        end = all_x[min(len(all_x) - 1, max(2, (2 * len(all_x)) // 3))]
        x_window = (start, end)

    # Use only the points inside the requested zoom range. When zoom_methods is
    # provided, the inset focuses only on curves that are actually close enough
    # to need zooming; obvious far-apart baselines are left out of the inset.
    inset_methods = zoom_methods or methods
    inset_rows = [
        row
        for row in agg
        if x_window[0] <= float(row["x"]) <= x_window[1] and row["method"] in inset_methods
    ]
    if len(inset_rows) < 2:
        return

    y_values = [float(row["mean"]) for row in inset_rows]
    y_span = max(y_values) - min(y_values)
    # Padding is data-driven so the inset has breathing room without changing
    # any plotted value.
    y_pad = max(y_span * 0.18, abs(mean(y_values)) * 0.01, 1e-9)

    # Inset coordinates are in axes-relative units: [left, bottom, width, height].
    # Per-figure locations are chosen to avoid hiding the main trend lines.
    inset_boxes = {
        "center": [0.48, 0.45, 0.30, 0.28],
        "upper_left": [0.12, 0.62, 0.30, 0.28],
        "upper_center": [0.36, 0.62, 0.30, 0.28],
        "upper_right": [0.64, 0.62, 0.30, 0.28],
        "upper_center_small": [0.38, 0.68, 0.22, 0.18],
        "middle_center": [0.36, 0.36, 0.30, 0.28],
        "middle_right": [0.62, 0.38, 0.28, 0.24],
        "lower_left": [0.12, 0.10, 0.30, 0.28],
        "lower_center": [0.34, 0.04, 0.30, 0.22],
        "lower_right": [0.64, 0.06, 0.28, 0.24],
    }
    inset = ax.inset_axes(inset_boxes.get(loc, inset_boxes["center"]))
    inset.set_facecolor("white")
    for method in inset_methods:
        # Match the parent plot style so the inset legend is not needed.
        method_rows = [row for row in inset_rows if row["method"] == method]
        x = np.array([row["x"] for row in method_rows], dtype=float)
        y = np.array([row["mean"] for row in method_rows], dtype=float)
        meta = METHODS[method]
        inset.plot(
            x,
            y,
            color=meta["color"],
            marker=meta["marker"],
            linestyle=meta["linestyle"],
            linewidth=1.2,
            markersize=3.2,
        )
    # Runtime scalability uses a log y-axis, so the inset must use the same scale
    # to avoid giving a different visual interpretation from the parent plot.
    inset.set_yscale(ax.get_yscale())
    y_lower = min(y_values) - y_pad
    if ax.get_yscale() == "log":
        positive_values = [value for value in y_values if value > 0]
        if not positive_values:
            return
        y_lower = max(y_lower, min(positive_values) * 0.8)
    inset.set_xlim(x_window[0], x_window[1])
    inset.set_ylim(y_lower, max(y_values) + y_pad)
    # Keep the inset simple: no shaded confidence bands and no arrow clutter.
    inset.grid(True, alpha=0.22, linestyle=":")
    inset.tick_params(labelsize=7)


def add_zoom_callout(
    ax,
    *,
    ellipse_center: tuple[float, float],
    ellipse_width: float,
    ellipse_height: float,
    arrow_start: tuple[float, float],
    arrow_end_axes: tuple[float, float],
) -> None:
    # Visual-only annotation: it connects the parent-axis source region with
    # the inset, without touching any computed metric or plotted data point.
    ellipse = Ellipse(
        ellipse_center,
        width=ellipse_width,
        height=ellipse_height,
        fill=False,
        edgecolor="black",
        linewidth=1.0,
        zorder=6,
    )
    ax.add_patch(ellipse)
    ax.annotate(
        "",
        xy=arrow_end_axes,
        xycoords="axes fraction",
        xytext=arrow_start,
        textcoords="data",
        arrowprops={
            "arrowstyle": "->",
            "color": "black",
            "linewidth": 1.0,
            "mutation_scale": 13,
            "shrinkA": 0,
            "shrinkB": 0,
        },
        zorder=7,
    )


def run_sweep(
    study_dir: Path,
    sweep_name: str,
    methods: list[str],
    x_values: list[float],
    build_base_config,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for x_value in x_values:
        for seed in SEEDS:
            base = build_base_config(x_value, seed)
            for method in methods:
                run_dir = study_dir / "raw_runs" / sweep_name / f"x_{x_value:g}" / method / f"seed_{seed}"
                run_dir.mkdir(parents=True, exist_ok=True)
                config = method_config(base, method, run_dir)
                print(f"{sweep_name}: {METHODS[method]['description']} | x={x_value:g} | seed={seed}")
                metrics = run_method(method, config)
                rows.append({"sweep": sweep_name, "method": method, "x": x_value, "seed": seed, **metrics})
    write_rows(study_dir / f"{sweep_name}_raw.csv", rows)
    return rows


def plot_metric(
    rows: list[dict[str, object]],
    path: Path,
    metric: str,
    xlabel: str,
    ylabel: str,
    methods: list[str],
    *,
    xticks: list[float] | None = None,
    yscale: str = "linear",
    zoom_window: tuple[float, float] | None = None,
    zoom_loc: str = "center",
    zoom_methods: list[str] | None = None,
    zoom_callout: dict[str, object] | None = None,
) -> None:
    fig, ax = plt.subplots(figsize=(7.1, 4.2))
    agg = aggregate(rows, metric)
    for method in methods:
        # Each plotted point is the aggregate mean over seeds for one method and
        # one sweep value. Standard deviation is computed in aggregate(), but we
        # intentionally do not draw shaded bands because the target figures should
        # show clean trend lines.
        method_rows = [row for row in agg if row["method"] == method]
        x = np.array([row["x"] for row in method_rows], dtype=float)
        y = np.array([row["mean"] for row in method_rows], dtype=float)
        std = np.array([row["std"] for row in method_rows], dtype=float)
        meta = METHODS[method]
        ax.plot(
            x,
            y,
            label=meta["symbol"],
            color=meta["color"],
            marker=meta["marker"],
            linestyle=meta["linestyle"],
            linewidth=1.8,
            markersize=5,
            clip_on=False,
        )
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if xticks is not None:
        ax.set_xticks(xticks)
    # Important paper-formatting choice: the x-axis begins at the first real
    # measured sweep value, not at zero.
    apply_measured_xlim(ax, xticks if xticks is not None else measured_x_values(agg))
    ax.set_yscale(yscale)
    if zoom_window is not None:
        # Add zoom only for crowded plots. Simple threshold/tradeoff plots omit it.
        add_zoom_inset(
            ax,
            agg,
            methods,
            x_window=zoom_window,
            loc=zoom_loc,
            zoom_methods=zoom_methods,
        )
    if zoom_callout is not None:
        add_zoom_callout(ax, **zoom_callout)
    ax.legend(ncol=2, frameon=True, framealpha=0.93)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def copy_named_figures(figure_dir: Path) -> None:
    paste_dir = figure_dir.parent / "paste_ready_figures"
    paste_dir.mkdir(exist_ok=True)
    names = {
        "fig01_average_service_delay_vs_U.png": "Fig_1_Average_Service_Delay_vs_Number_of_UAV_Tasks.png",
        "fig02_total_weighted_cost_vs_U.png": "Fig_2_Total_Weighted_DTN_Cost_vs_Number_of_UAV_Tasks.png",
        "fig03_average_energy_vs_U.png": "Fig_3_Total_Energy_Consumption_vs_Number_of_UAV_Tasks.png",
        "fig04_freshness_risk_cost_vs_A_bar.png": "Fig_4_Freshness_Risk_Mission_Cost_vs_Average_AoI.png",
        "fig05_twin_fidelity_vs_v.png": "Fig_5_Digital_Twin_Fidelity_vs_UAV_Speed.png",
        "fig06_sync_overhead_vs_delta_A.png": "Fig_6_Synchronization_Overhead_vs_Twin_Age_Threshold.png",
        "fig07_coord_overhead_vs_delta_tau.png": "Fig_7_Regional_Coordination_Overhead_vs_Trust_Threshold.png",
        "fig08_runtime_scalability_vs_U.png": "Fig_8_Runtime_Scalability_vs_Number_of_UAV_Tasks.png",
        "fig09_cost_sync_tradeoff_vs_delta_A.png": "Fig_9_Total_Cost_and_Synchronization_Tradeoff_vs_Twin_Age_Threshold.png",
    }
    for source_name, target_name in names.items():
        source = figure_dir / source_name
        if source.exists():
            (paste_dir / target_name).write_bytes(source.read_bytes())


def plot_tradeoff(rows: list[dict[str, object]], path: Path, methods: list[str]) -> None:
    fig, ax1 = plt.subplots(figsize=(7.6, 4.5))
    ax2 = ax1.twinx()
    cost_rows = aggregate(rows, "avg_total_cost")
    sync_rows = aggregate(rows, "avg_sync")
    for method in methods:
        meta = METHODS[method]
        method_cost = [row for row in cost_rows if row["method"] == method]
        method_sync = [row for row in sync_rows if row["method"] == method]
        if method != "proposed":
            reference_x = 1.0 if method == "always_on" else 3.0
            method_cost = min(method_cost, key=lambda row: abs(float(row["x"]) - reference_x))
            method_sync = min(method_sync, key=lambda row: abs(float(row["x"]) - reference_x))
            ax1.scatter(
                [method_cost["x"]],
                [method_cost["mean"]],
                label=meta["symbol"] + r"$:\overline{J}$",
                color=meta["color"],
                marker=meta["marker"],
                s=55,
                zorder=5,
            )
            ax2.scatter(
                [method_sync["x"]],
                [method_sync["mean"]],
                label=meta["symbol"] + r"$:\overline{\mathcal{O}}_{\mathrm{sync}}$",
                color=meta["color"],
                marker="x",
                s=55,
                zorder=5,
            )
            continue
        x = np.array([row["x"] for row in method_cost], dtype=float)
        cost = np.array([row["mean"] for row in method_cost], dtype=float)
        ax1.plot(
            x,
            cost,
            label=meta["symbol"] + r"$:\overline{J}$",
            color=meta["color"],
            marker=meta["marker"],
            linestyle="-",
            linewidth=1.8,
        )

        sync = np.array([row["mean"] for row in method_sync], dtype=float)
        ax2.plot(
            x,
            sync,
            label=meta["symbol"] + r"$:\overline{\mathcal{O}}_{\mathrm{sync}}$",
            color=meta["color"],
            marker="x",
            linestyle="--",
            linewidth=1.6,
        )
    ax1.set_xlabel(r"Twin-Age Synchronization Threshold [$\delta_A$, slots]")
    ax1.set_ylabel(r"Average Total Weighted DTN Cost [$\overline{J}$, cost/slot]")
    ax2.set_ylabel(r"Synchronization Overhead [$\overline{\mathcal{O}}_{\mathrm{sync}}$, events/slot]")
    tradeoff_x = sorted({float(row["x"]) for row in rows})
    ax1.set_xticks(tradeoff_x)
    apply_measured_xlim(ax1, tradeoff_x)
    ax2.grid(False)
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(
        h1 + h2,
        l1 + l2,
        ncol=3,
        loc="upper center",
        frameon=True,
        framealpha=0.93,
    )
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_existing_results(study_dir: Path) -> None:
    figure_dir = study_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)

    workload_rows = read_rows(study_dir / "uav_task_sweep_raw.csv")
    aoi_rows = read_rows(study_dir / "aoi_sweep_raw.csv")
    speed_rows = read_rows(study_dir / "mobility_sweep_raw.csv")
    sync_rows = read_rows(study_dir / "sync_threshold_sweep_raw.csv")
    coord_rows = read_rows(study_dir / "coord_threshold_sweep_raw.csv")
    tradeoff_rows = read_rows(study_dir / "tradeoff_sweep_raw.csv")

    fig1_methods = ["proposed", "greedy", "dt_free", "channel_only", "centralized_qubo", "local_search", "aoi_unaware"]
    fig2_methods = ["proposed", "always_on", "centralized_qubo", "uncertainty_unaware", "static_risk", "dt_free"]
    fig3_methods = ["proposed", "greedy", "dt_free", "channel_only", "local_search", "uncertainty_unaware"]
    fig4_methods = ["proposed", "aoi_unaware", "trust_unaware", "static_risk", "channel_only", "uncertainty_unaware"]
    fig5_methods = ["proposed", "channel_only", "static_risk", "aoi_unaware", "uncertainty_unaware", "dt_free"]
    fig6_methods = ["proposed", "always_on", "uncertainty_unaware"]
    fig7_methods = ["proposed", "always_on", "uncertainty_unaware"]
    fig8_methods = ["proposed", "centralized_qubo", "local_qubo", "local_search", "dt_free"]

    task_ticks = measured_x_values(workload_rows)
    aoi_ticks = measured_x_values(aoi_rows)
    speed_ticks = measured_x_values(speed_rows)
    sync_ticks = measured_x_values(sync_rows)
    coord_ticks = measured_x_values(coord_rows)

    # Fig. 1 trends are clear in the main axes, so no zoom is added.
    plot_metric(
        workload_rows,
        figure_dir / "fig01_average_service_delay_vs_U.png",
        "avg_delay",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Average Service Delay [$\overline{T}$, ms/task]",
        fig1_methods,
        xticks=task_ticks,
    )
    # Fig. 2 is already readable in the parent axes, so the inset is removed.
    plot_metric(
        workload_rows,
        figure_dir / "fig02_total_weighted_cost_vs_U.png",
        "avg_total_cost",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Average Total Weighted DTN Cost [$\overline{J}$, cost/slot]",
        fig2_methods,
        xticks=task_ticks,
    )
    # Fig. 3 is kept without an inset; the full energy trend is readable in the
    # parent axes and avoids extra visual clutter.
    plot_metric(
        workload_rows,
        figure_dir / "fig03_average_energy_vs_U.png",
        "avg_energy",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Average Energy Consumption [$\overline{E}$, J/task]",
        fig3_methods,
        xticks=task_ticks,
    )
    # Fig. 4 zooms the low-cost clustered curves only; high-cost curves are clear
    # in the parent axes. The inset is restricted to A_bar=3..5 so there is no
    # unused right-side whitespace, and the callout marks the zoomed source area.
    plot_metric(
        aoi_rows,
        figure_dir / "fig04_freshness_risk_cost_vs_A_bar.png",
        "avg_mission_cost",
        r"Average Initial Age of Information [$\overline{A}$, slots]",
        r"Freshness-Risk Mission Cost [$\overline{C}_{\mathrm{FR}}$, cost/task]",
        fig4_methods,
        xticks=aoi_ticks,
        zoom_window=(aoi_ticks[1], aoi_ticks[2]) if len(aoi_ticks) >= 3 else None,
        zoom_loc="middle_right",
        zoom_methods=["proposed", "aoi_unaware", "trust_unaware", "uncertainty_unaware"],
        zoom_callout={
            "ellipse_center": (4.0, 0.060),
            "ellipse_width": 1.45,
            "ellipse_height": 0.036,
            "arrow_start": (4.6, 0.077),
            "arrow_end_axes": (0.63, 0.42),
        },
    )
    # Fig. 5 trends are clear in the main axes, so no zoom is added.
    plot_metric(
        speed_rows,
        figure_dir / "fig05_twin_fidelity_vs_v.png",
        "avg_fidelity",
        r"Average UAV Speed [$v$, m/s]",
        r"Average Digital Twin Fidelity [$\overline{F}$, unitless]",
        fig5_methods,
        xticks=speed_ticks,
    )
    # Fig. 6 trends are clear in the main axes, so no zoom is added.
    plot_metric(
        sync_rows,
        figure_dir / "fig06_sync_overhead_vs_delta_A.png",
        "avg_sync",
        r"Twin-Age Synchronization Threshold [$\delta_A$, slots]",
        r"Synchronization Overhead [$\overline{\mathcal{O}}_{\mathrm{sync}}$, events/slot]",
        fig6_methods,
        xticks=sync_ticks,
    )
    # Fig. 7 is also a threshold-overhead plot with few methods, so adding zoom
    # would add clutter without improving interpretation.
    plot_metric(
        coord_rows,
        figure_dir / "fig07_coord_overhead_vs_delta_tau.png",
        "avg_coord",
        r"Coordination Trust Threshold [$\delta_\tau$, unitless]",
        r"Regional Coordination Overhead [$\overline{\mathcal{O}}_{\mathrm{coord}}$, events/slot]",
        fig7_methods,
        xticks=coord_ticks,
    )
    # Fig. 8 uses log-scale runtime and does not need a zoom box.
    plot_metric(
        workload_rows,
        figure_dir / "fig08_runtime_scalability_vs_U.png",
        "avg_runtime_ms",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Decision Runtime [$t_{\mathrm{dec}}$, ms/slot]",
        fig8_methods,
        xticks=task_ticks,
        yscale="log",
    )
    plot_tradeoff(
        tradeoff_rows,
        figure_dir / "fig09_cost_sync_tradeoff_vs_delta_A.png",
        ["proposed", "always_on", "uncertainty_unaware"],
    )
    copy_named_figures(figure_dir)
    print(f"Replotted measured baseline figures in: {study_dir.resolve()}")


def write_symbol_key(path: Path) -> None:
    lines = ["Measured baseline symbol key", ""]
    for key, meta in METHODS.items():
        lines.append(f"{meta['symbol']} = {meta['description']}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    global SEEDS
    args = parse_args()
    configure_plots(args.dpi)
    if args.replot_from:
        plot_existing_results(Path(args.replot_from))
        return

    SEEDS = parse_ints(args.seeds)
    task_values = parse_ints(args.tasks)
    aoi_values = parse_ints(args.aoi_values)
    speeds = parse_floats(args.speeds)
    sync_thresholds = parse_ints(args.sync_thresholds)
    tradeoff_thresholds = parse_ints(args.tradeoff_thresholds)
    coord_thresholds = parse_floats(args.coord_thresholds)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    study_dir = Path(args.output_dir) / f"measured_{timestamp}"
    figure_dir = study_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    write_symbol_key(study_dir / "symbol_key.txt")
    (study_dir / "study_config.json").write_text(
        json.dumps(vars(args) | {"methods": METHODS}, indent=2, default=str),
        encoding="utf-8",
    )

    workload_union = [
        "proposed",
        "greedy",
        "centralized_qubo",
        "dt_free",
        "channel_only",
        "static_risk",
        "aoi_unaware",
        "always_on",
        "local_qubo",
        "local_search",
        "uncertainty_unaware",
    ]
    fig1_methods = [
        "proposed",
        "greedy",
        "dt_free",
        "channel_only",
        "centralized_qubo",
        "local_search",
        "aoi_unaware",
    ]
    fig2_methods = [
        "proposed",
        "always_on",
        "centralized_qubo",
        "uncertainty_unaware",
        "static_risk",
        "dt_free",
    ]
    fig3_methods = [
        "proposed",
        "greedy",
        "dt_free",
        "channel_only",
        "local_search",
        "uncertainty_unaware",
    ]
    fig4_methods = [
        "proposed",
        "aoi_unaware",
        "trust_unaware",
        "static_risk",
        "channel_only",
        "uncertainty_unaware",
    ]
    fig5_methods = [
        "proposed",
        "channel_only",
        "static_risk",
        "aoi_unaware",
        "uncertainty_unaware",
        "dt_free",
    ]
    fig6_methods = ["proposed", "always_on", "uncertainty_unaware"]
    fig7_methods = ["proposed", "always_on", "uncertainty_unaware"]
    fig8_methods = [
        "proposed",
        "centralized_qubo",
        "local_qubo",
        "local_search",
        "dt_free",
    ]

    workload_rows = run_sweep(
        study_dir,
        "uav_task_sweep",
        workload_union,
        [float(value) for value in task_values],
        lambda x, seed: SimulationConfig(
            slots=args.slots,
            seed=seed,
            num_uavs=int(x),
            anneal_reads=args.anneal_reads,
            anneal_sweeps=args.anneal_sweeps,
            small_qubo_exact_threshold=0,
        ),
    )
    plot_metric(
        workload_rows,
        figure_dir / "fig01_average_service_delay_vs_U.png",
        "avg_delay",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Average Service Delay [$\overline{T}$, ms/task]",
        fig1_methods,
        xticks=[float(value) for value in task_values],
    )
    plot_metric(
        workload_rows,
        figure_dir / "fig02_total_weighted_cost_vs_U.png",
        "avg_total_cost",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Average Total Weighted DTN Cost [$\overline{J}$, cost/slot]",
        fig2_methods,
        xticks=[float(value) for value in task_values],
    )
    plot_metric(
        workload_rows,
        figure_dir / "fig03_average_energy_vs_U.png",
        "avg_energy",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Average Energy Consumption [$\overline{E}$, J/task]",
        fig3_methods,
        xticks=[float(value) for value in task_values],
    )
    plot_metric(
        workload_rows,
        figure_dir / "fig08_runtime_scalability_vs_U.png",
        "avg_runtime_ms",
        r"Number of UAV Tasks [$U$, tasks]",
        r"Decision Runtime [$t_{\mathrm{dec}}$, ms/slot]",
        fig8_methods,
        xticks=[float(value) for value in task_values],
        yscale="log",
    )

    aoi_rows = run_sweep(
        study_dir,
        "aoi_sweep",
        fig4_methods,
        [float(value) for value in aoi_values],
        lambda x, seed: SimulationConfig(
            slots=args.slots,
            seed=seed,
            num_uavs=40,
            task_aoi_min=1,
            task_aoi_max=max(1, int(2 * x - 1)),
            anneal_reads=args.anneal_reads,
            anneal_sweeps=args.anneal_sweeps,
            small_qubo_exact_threshold=0,
        ),
    )
    plot_metric(
        aoi_rows,
        figure_dir / "fig04_freshness_risk_cost_vs_A_bar.png",
        "avg_mission_cost",
        r"Average Initial Age of Information [$\overline{A}$, slots]",
        r"Freshness-Risk Mission Cost [$\overline{C}_{\mathrm{FR}}$, cost/task]",
        fig4_methods,
        xticks=[float(value) for value in aoi_values],
        zoom_window=(float(aoi_values[1]), float(aoi_values[2])) if len(aoi_values) >= 3 else None,
        zoom_loc="middle_right",
        zoom_methods=["proposed", "aoi_unaware", "trust_unaware", "uncertainty_unaware"],
        zoom_callout={
            "ellipse_center": (4.0, 0.060),
            "ellipse_width": 1.45,
            "ellipse_height": 0.036,
            "arrow_start": (4.6, 0.077),
            "arrow_end_axes": (0.63, 0.42),
        },
    )

    speed_rows = run_sweep(
        study_dir,
        "mobility_sweep",
        fig5_methods,
        speeds,
        lambda x, seed: SimulationConfig(
            slots=args.slots,
            seed=seed,
            num_uavs=40,
            uav_velocity_xy_min=-float(x),
            uav_velocity_xy_max=float(x),
            uav_velocity_z_min=-0.15 * float(x),
            uav_velocity_z_max=0.15 * float(x),
            anneal_reads=args.anneal_reads,
            anneal_sweeps=args.anneal_sweeps,
            small_qubo_exact_threshold=0,
        ),
    )
    plot_metric(
        speed_rows,
        figure_dir / "fig05_twin_fidelity_vs_v.png",
        "avg_fidelity",
        r"Average UAV Speed [$v$, m/s]",
        r"Average Digital Twin Fidelity [$\overline{F}$, unitless]",
        fig5_methods,
        xticks=speeds,
    )

    sync_rows = run_sweep(
        study_dir,
        "sync_threshold_sweep",
        fig6_methods,
        [float(value) for value in sync_thresholds],
        lambda x, seed: SimulationConfig(
            slots=args.slots,
            seed=seed,
            num_uavs=40,
            sync_age_threshold=int(x),
            sync_uncertainty_threshold=10.0,
            sync_mismatch_threshold=10.0,
            sync_fidelity_trigger=False,
            anneal_reads=args.anneal_reads,
            anneal_sweeps=args.anneal_sweeps,
            small_qubo_exact_threshold=0,
        ),
    )
    plot_metric(
        sync_rows,
        figure_dir / "fig06_sync_overhead_vs_delta_A.png",
        "avg_sync",
        r"Twin-Age Synchronization Threshold [$\delta_A$, slots]",
        r"Synchronization Overhead [$\overline{\mathcal{O}}_{\mathrm{sync}}$, events/slot]",
        fig6_methods,
        xticks=[float(value) for value in sync_thresholds],
    )

    coord_rows = run_sweep(
        study_dir,
        "coord_threshold_sweep",
        fig7_methods,
        coord_thresholds,
        lambda x, seed: SimulationConfig(
            slots=args.slots,
            seed=seed,
            num_uavs=40,
            coord_trust_threshold=float(x),
            coord_state_threshold=10.0,
            coord_uncertainty_threshold=10.0,
            coord_mismatch_threshold=10.0,
            coord_app_pressure_threshold=10.0,
            anneal_reads=args.anneal_reads,
            anneal_sweeps=args.anneal_sweeps,
            small_qubo_exact_threshold=0,
        ),
    )
    plot_metric(
        coord_rows,
        figure_dir / "fig07_coord_overhead_vs_delta_tau.png",
        "avg_coord",
        r"Coordination Trust Threshold [$\delta_\tau$, unitless]",
        r"Regional Coordination Overhead [$\overline{\mathcal{O}}_{\mathrm{coord}}$, events/slot]",
        fig7_methods,
        xticks=coord_thresholds,
    )

    tradeoff_rows = run_sweep(
        study_dir,
        "tradeoff_sweep",
        ["proposed", "always_on", "uncertainty_unaware"],
        [float(value) for value in tradeoff_thresholds],
        lambda x, seed: SimulationConfig(
            slots=args.slots,
            seed=seed,
            num_uavs=40,
            sync_age_threshold=int(x),
            sync_uncertainty_threshold=10.0,
            sync_mismatch_threshold=10.0,
            sync_fidelity_trigger=False,
            anneal_reads=args.anneal_reads,
            anneal_sweeps=args.anneal_sweeps,
            small_qubo_exact_threshold=0,
            periodic_sync_period=3,
            periodic_coord_period=3,
        ),
    )
    plot_tradeoff(
        tradeoff_rows,
        figure_dir / "fig09_cost_sync_tradeoff_vs_delta_A.png",
        ["proposed", "always_on", "uncertainty_unaware"],
    )
    copy_named_figures(figure_dir)
    print(f"Measured baseline study saved in: {study_dir.resolve()}")


if __name__ == "__main__":
    SEEDS: list[int] = []
    main()
