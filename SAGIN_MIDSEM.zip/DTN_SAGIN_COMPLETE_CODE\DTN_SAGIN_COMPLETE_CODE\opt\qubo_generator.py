from __future__ import annotations

from collections import defaultdict

from env.config import SimulationConfig
from env.evaluator import PhysicalEvaluator
from env.feasibility import FeasibilityManager
from env.models import APNode, CandidateScore, QuboProblem, Task


class LocalQuboBuilder:
    """Build the paper's local assignment QUBO over task-destination binaries."""

    def __init__(self, config: SimulationConfig):
        self.config = config
        self.evaluator = PhysicalEvaluator(config)
        self.feasibility = FeasibilityManager(config)

    def build(
        self,
        ap: APNode,
        tasks: list[Task],
        ap_lookup: dict[str, APNode],
        slot: int,
        sync_ap_ids: set[str] | None = None,
        coord_ap_ids: set[str] | None = None,
    ) -> QuboProblem:
        sync_ap_ids = sync_ap_ids or set()
        coord_ap_ids = coord_ap_ids or set()
        scores = self.score_candidates(
            ap,
            tasks,
            ap_lookup,
            sync_ap_ids=sync_ap_ids,
            coord_ap_ids=coord_ap_ids,
        )
        variables = [
            (score.task_id, score.destination_id)
            for score in scores
        ]
        penalty = self.config.qubo_penalty
        linear = {
            (score.task_id, score.destination_id): score.local_cost - penalty
            for score in scores
        }
        quadratic: dict[
            tuple[tuple[str, str], tuple[str, str]],
            float,
        ] = {}

        variables_by_task: dict[str, list[tuple[str, str]]] = defaultdict(list)
        variables_by_destination: dict[str, list[tuple[str, str]]] = defaultdict(list)
        task_by_id = {task.task_id: task for task in tasks}
        for variable in variables:
            variables_by_task[variable[0]].append(variable)
            variables_by_destination[variable[1]].append(variable)

        # P(1 - sum_m x_um)^2: -P on each binary and +2P on task pairs.
        for task_variables in variables_by_task.values():
            for left_index, left in enumerate(task_variables):
                for right in task_variables[left_index + 1 :]:
                    quadratic[(left, right)] = 2.0 * penalty

        # Quadratic congestion approximation for tasks sharing one destination.
        for destination, destination_variables in variables_by_destination.items():
            ap_capacity = self.feasibility.capacity(ap_lookup[destination])
            for left_index, left in enumerate(destination_variables):
                left_demand = self.feasibility.task_demand(task_by_id[left[0]])
                for right in destination_variables[left_index + 1 :]:
                    right_demand = self.feasibility.task_demand(task_by_id[right[0]])
                    coupling = self.config.qubo_load_coupling * (
                        left_demand.cpu_cycles
                        * right_demand.cpu_cycles
                        / max(ap_capacity.cpu_cycles**2, 1e-12)
                        + left_demand.communication_bits
                        * right_demand.communication_bits
                        / max(ap_capacity.communication_bits**2, 1e-12)
                        + left_demand.power_watts
                        * right_demand.power_watts
                        / max(ap_capacity.power_watts**2, 1e-12)
                    )
                    quadratic[(left, right)] = (
                        quadratic.get((left, right), 0.0) + coupling
                    )

        return QuboProblem(
            ap_id=ap.ap_id,
            slot=slot,
            local_load=max(float(ap.current_task_load + len(tasks)), 1.0),
            variables=variables,
            linear=linear,
            quadratic=quadratic,
            penalty_mu=penalty,
            penalty_by_task={task.task_id: penalty for task in tasks},
            candidate_scores=scores,
        )

    def score_candidates(
        self,
        owner_ap: APNode,
        tasks: list[Task],
        ap_lookup: dict[str, APNode],
        preferred_pairs: set[tuple[str, str]] | None = None,
        sync_ap_ids: set[str] | None = None,
        coord_ap_ids: set[str] | None = None,
    ) -> list[CandidateScore]:
        sync_ap_ids = sync_ap_ids or set()
        coord_ap_ids = coord_ap_ids or set()
        scores: list[CandidateScore] = []
        for task in tasks:
            for destination_id in task.A_u_t:
                destination = ap_lookup[destination_id]
                load_count = max(float(destination.current_task_load + 1), 1.0)
                metrics = self.evaluator.evaluate_remote(
                    task,
                    destination,
                    load_count,
                    sync_active=destination_id in sync_ap_ids,
                    coord_active=destination_id in coord_ap_ids,
                )
                guidance_penalty = (
                    self.config.qubo_guidance_penalty
                    if preferred_pairs is not None
                    and (task.task_id, destination_id) not in preferred_pairs
                    else 0.0
                )
                demand = self.feasibility.task_demand(task)
                scores.append(
                    CandidateScore(
                        task_id=task.task_id,
                        owner_ap_id=owner_ap.ap_id,
                        destination_id=destination_id,
                        local_cost=self.evaluator.proposed_cost(metrics),
                        delay_cost=metrics.total_delay_s,
                        energy_cost=metrics.total_energy_j,
                        mission_cost=metrics.freshness_risk,
                        fidelity_cost=metrics.fidelity_penalty,
                        coupling_penalty=(
                            destination.coordination_state.coupling_penalty
                            + guidance_penalty
                        ),
                        projected_load=load_count,
                        required_bandwidth=(
                            demand.communication_bits
                            / max(
                                self.config.slot_duration_seconds
                                * self.config.mbps_to_bits_per_second,
                                1e-12,
                            )
                        ),
                        required_cpu=(
                            demand.cpu_cycles
                            / max(
                                self.config.slot_duration_seconds
                                * self.config.ghz_to_hz,
                                1e-12,
                            )
                        ),
                        required_power=demand.power_watts,
                    )
                )
        return scores
